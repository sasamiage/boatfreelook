package com.example.boatfreelook.mixin;

import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin {

    // バニラはボートの操縦キー(W/A/S/D)を押している間 handsBusy=true にして、
    // 手を画面から下げ、アイテムの右クリック使用も禁止している。それを毎tick打ち消す。
    @Shadow
    private boolean handsBusy;

    @Inject(method = "rideTick", at = @At("TAIL"))
    private void boatfreelook$freeHands(CallbackInfo ci) {
        this.handsBusy = false;
    }
}
