package com.example.boatfreelook.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.Boat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Boat.class)
public abstract class BoatMixin {

    // プレイヤーの視点(yaw)を ±105° に制限する処理をやめる → 360°回せる
    @Inject(method = "clampRotation", at = @At("HEAD"), cancellable = true)
    private void boatfreelook$noClamp(Entity entity, CallbackInfo ci) {
        if (entity instanceof Player) {
            entity.setYBodyRot(((Boat) (Object) this).getYRot());
            ci.cancel();
        }
    }

    // ボートが旋回したとき、プレイヤーの視点が一緒に引っ張られるのを止める
    @WrapWithCondition(method = "positionRider",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;setYRot(F)V"))
    private boolean boatfreelook$keepYaw(Entity passenger, float yaw) {
        return !(passenger instanceof Player);
    }

    @WrapWithCondition(method = "positionRider",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;setYHeadRot(F)V"))
    private boolean boatfreelook$keepHeadYaw(Entity passenger, float yaw) {
        return !(passenger instanceof Player);
    }
}
