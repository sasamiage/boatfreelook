package com.example.boatfreelook;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(BoatFreeLook.MOD_ID)
public class BoatFreeLook {
    public static final String MOD_ID = "boatfreelook";

    public BoatFreeLook(IEventBus modEventBus) {
        // 処理はすべてMixin側。ここは空でOK
    }
}
