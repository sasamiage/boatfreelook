package com.example.voidsaver;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@Mod(VoidSaver.MOD_ID)
public class VoidSaver {
    public static final String MOD_ID = "voidsaver";

    /** 探す範囲（ブロック）。大きくすると遠くまで探すが重くなる */
    private static final int SEARCH_RADIUS = 48;
    /** 着地先が見つからなかったとき、次に探すまでの待ち時間(tick) */
    private static final int RETRY_TICKS = 40;

    private static final Map<UUID, Long> NEXT_TRY = new HashMap<>();

    private record Spot(double x, double y, double z, double distSq) {}

    public VoidSaver(IEventBus modEventBus) {
        NeoForge.EVENT_BUS.addListener(VoidSaver::onPlayerTick);
    }

    private static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(player.level() instanceof ServerLevel level)) return;

        // 世界の底より下に落ちたときだけ動く
        if (player.getY() >= level.getMinBuildHeight()) {
            NEXT_TRY.remove(player.getUUID());
            return;
        }
        if (player.isSpectator() || player.getAbilities().flying) return;

        long now = level.getGameTime();
        Long next = NEXT_TRY.get(player.getUUID());
        if (next != null && now < next) return;

        Spot spot = findNearest(level, player);
        if (spot == null) {
            NEXT_TRY.put(player.getUUID(), now + RETRY_TICKS);
            return;
        }

        NEXT_TRY.remove(player.getUUID());
        player.stopRiding();
        player.connection.teleport(spot.x(), spot.y(), spot.z(), player.getYRot(), player.getXRot());
        player.fallDistance = 0.0F;
        player.setDeltaMovement(Vec3.ZERO);
        player.hurtMarked = true;
        level.playSound(null, spot.x(), spot.y(), spot.z(),
                SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
    }

    /** 落ちた地点から近い順に、立てる場所を探す */
    private static Spot findNearest(ServerLevel level, ServerPlayer player) {
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight() - 3;
        int ox = Mth.floor(player.getX());
        int oz = Mth.floor(player.getZ());
        int oy = minY;

        Spot best = null;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int r = 0; r <= SEARCH_RADIUS; r++) {
            // 距離 r の「殻」だけを調べる（内側は前の周で調べ済み）
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    int y = oy + dy;
                    if (y < minY || y > maxY) continue;
                    boolean edge = Math.abs(dx) == r || Math.abs(dy) == r;
                    int step = edge ? 1 : Math.max(1, 2 * r);
                    for (int dz = -r; dz <= r; dz += step) {
                        pos.set(ox + dx, y, oz + dz);
                        Spot s = check(level, player, pos);
                        if (s == null) continue;
                        double d = (double) dx * dx + (double) dy * dy + (double) dz * dz;
                        if (best == null || d < best.distSq()) {
                            best = new Spot(s.x(), s.y(), s.z(), d);
                        }
                    }
                }
            }
            // 次の殻の点は必ず (r+1) 以上遠いので、それより近い候補があれば確定
            if (best != null && best.distSq() <= (r + 1.0) * (r + 1.0)) break;
        }
        return best;
    }

    /** そのブロックの上にプレイヤーが立てるなら、立つ位置を返す */
    private static Spot check(ServerLevel level, ServerPlayer player, BlockPos floor) {
        if (!level.hasChunkAt(floor)) return null;

        BlockState state = level.getBlockState(floor);
        if (state.isAir() || !state.getFluidState().isEmpty()) return null;
        if (state.is(Blocks.MAGMA_BLOCK) || state.is(Blocks.CACTUS)
                || state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE)) return null;

        VoxelShape shape = state.getCollisionShape(level, floor);
        if (shape.isEmpty()) return null;

        double top = floor.getY() + shape.max(Direction.Axis.Y);
        double x = floor.getX() + 0.5;
        double z = floor.getZ() + 0.5;

        AABB box = player.getDimensions(Pose.STANDING).makeBoundingBox(x, top, z);
        if (!level.noCollision(player, box)) return null;
        if (level.containsAnyLiquid(box)) return null;

        return new Spot(x, top, z, 0);
    }
}
