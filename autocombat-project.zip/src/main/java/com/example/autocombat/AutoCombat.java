package com.example.autocombat;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * クライアント専用Mod。
 *  - 攻撃ボタンを押している間、攻撃クールダウンが溜まった瞬間に自動で攻撃
 *  - 満腹度が「アイコン2.5個分(=5)」減ったら、オフハンドのパンを自動で食べる
 *  - キー(K / J) または /autocombat コマンドで ON/OFF
 */
@Mod(value = AutoCombat.MOD_ID, dist = Dist.CLIENT)
public class AutoCombat {
    public static final String MOD_ID = "autocombat";

    /** 満腹度がこれ以上減ったら食べる（5 = アイコン2.5個分 = パン1個ぶん） */
    private static final int HUNGER_GAP = 5;

    private static final String CATEGORY = "key.categories.autocombat";
    private static final KeyMapping TOGGLE_ATTACK =
            new KeyMapping("key.autocombat.toggle_attack", InputConstants.KEY_K, CATEGORY);
    private static final KeyMapping TOGGLE_EAT =
            new KeyMapping("key.autocombat.toggle_eat", InputConstants.KEY_J, CATEGORY);

    private static boolean autoAttack = true;
    private static boolean autoEat = true;
    private static boolean eatingByMod = false;
    private static int eatCooldown = 0;

    public AutoCombat(IEventBus modEventBus) {
        modEventBus.addListener(AutoCombat::onRegisterKeys);
        NeoForge.EVENT_BUS.addListener(AutoCombat::onClientTick);
        NeoForge.EVENT_BUS.addListener(AutoCombat::onRegisterCommands);
    }

    private static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE_ATTACK);
        event.register(TOGGLE_EAT);
    }

    private static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.gameMode == null) {
            eatingByMod = false;
            return;
        }

        while (TOGGLE_ATTACK.consumeClick()) {
            setAutoAttack(!autoAttack);
        }
        while (TOGGLE_EAT.consumeClick()) {
            setAutoEat(!autoEat);
        }

        if (mc.screen != null) return;

        handleEating(mc, player);
        handleAttack(mc, player);
    }

    // ---------------- 自動攻撃 ----------------
    private static void handleAttack(Minecraft mc, LocalPlayer player) {
        if (!autoAttack) return;
        if (!mc.options.keyAttack.isDown()) return;          // 攻撃ボタンを押している間だけ
        if (player.isUsingItem() || player.isSpectator()) return;
        if (!(mc.hitResult instanceof EntityHitResult hit)) return;
        if (!hit.getEntity().isAttackable()) return;
        if (player.getAttackStrengthScale(0.0F) < 1.0F) return; // クールダウンが溜まった瞬間

        mc.gameMode.attack(player, hit.getEntity());
        player.swing(InteractionHand.MAIN_HAND);
    }

    // ---------------- 自動パン ----------------
    private static void handleEating(Minecraft mc, LocalPlayer player) {
        if (eatingByMod) {
            // 食べ終わるまで「使用キー」を押している扱いにして、バニラの途中キャンセルを防ぐ
            if (player.isUsingItem() && player.getUsedItemHand() == InteractionHand.OFF_HAND) {
                mc.options.keyUse.setDown(true);
                return;
            }
            eatingByMod = false;
            mc.options.keyUse.setDown(false);
        }

        if (eatCooldown > 0) {
            eatCooldown--;
            return;
        }
        if (!autoEat || player.isUsingItem() || player.isSpectator()) return;
        if (!player.getOffhandItem().is(Items.BREAD)) return;
        if (20 - player.getFoodData().getFoodLevel() < HUNGER_GAP) return;

        mc.gameMode.useItem(player, InteractionHand.OFF_HAND);
        if (player.isUsingItem()) {
            eatingByMod = true;
            mc.options.keyUse.setDown(true);
        }
        eatCooldown = 20;
    }

    // ---------------- ON/OFF ----------------
    private static void setAutoAttack(boolean value) {
        autoAttack = value;
        message("自動攻撃: " + (value ? "ON" : "OFF"));
    }

    private static void setAutoEat(boolean value) {
        autoEat = value;
        message("自動パン: " + (value ? "ON" : "OFF"));
    }

    private static void message(String text) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null) {
            player.displayClientMessage(Component.literal(text), true);
        }
    }

    private static void onRegisterCommands(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("autocombat")
                        .then(Commands.literal("attack")
                                .executes(c -> { setAutoAttack(!autoAttack); return 1; })
                                .then(Commands.literal("on").executes(c -> { setAutoAttack(true); return 1; }))
                                .then(Commands.literal("off").executes(c -> { setAutoAttack(false); return 1; })))
                        .then(Commands.literal("eat")
                                .executes(c -> { setAutoEat(!autoEat); return 1; })
                                .then(Commands.literal("on").executes(c -> { setAutoEat(true); return 1; }))
                                .then(Commands.literal("off").executes(c -> { setAutoEat(false); return 1; })))
                        .executes(c -> {
                            message("自動攻撃: " + (autoAttack ? "ON" : "OFF")
                                    + " / 自動パン: " + (autoEat ? "ON" : "OFF"));
                            return 1;
                        }));
    }
}
